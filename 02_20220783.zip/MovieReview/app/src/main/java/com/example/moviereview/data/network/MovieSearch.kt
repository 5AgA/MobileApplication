package com.example.moviereview.data.network

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface MovieSearch {
    @GET("kobisopenapi/webservice/rest/movie/searchMovieList.json")
    suspend fun getMovieList(
        @Query("key") key: String,
        @Query("movieNm") movieNm: String,
    ): MovieRoot
}