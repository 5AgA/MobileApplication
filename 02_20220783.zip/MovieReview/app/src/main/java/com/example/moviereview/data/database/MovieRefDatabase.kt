package com.example.moviereview.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MovieEntity::class], version=1)
abstract class MovieRefDatabase : RoomDatabase() {
    abstract fun refDao() : MovieRefDao

    companion object {
        @Volatile
        private var INSTANCE : MovieRefDatabase? = null

        fun getDatabase(context: Context) : MovieRefDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext, MovieRefDatabase::class.java, "movie_ref"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}