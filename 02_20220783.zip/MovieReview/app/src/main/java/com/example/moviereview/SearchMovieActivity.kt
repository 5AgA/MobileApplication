package com.example.moviereview

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.moviereview.databinding.ActivitySearchMovieBinding
import com.example.moviereview.ui.MSViewModel
import com.example.moviereview.ui.MSViewModelFactory
import com.example.moviereview.ui.SearchMovieAdapter

class SearchMovieActivity: AppCompatActivity() {

    val searchMovieBinding by lazy {
        ActivitySearchMovieBinding.inflate(layoutInflater)
    }

    val searchMovieAdapter by lazy {
        SearchMovieAdapter(emptyList(), this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(searchMovieBinding.root)

        val viewModel : MSViewModel by viewModels {
            MSViewModelFactory((application as ReviewApplication).refRepository)
        }

        searchMovieBinding.movieListRv.adapter = searchMovieAdapter
        searchMovieBinding.movieListRv.layoutManager = LinearLayoutManager(this)

        viewModel.movies.observe(this) { movieList ->
            searchMovieAdapter.updateMovies(movieList ?: emptyList())
        }

        searchMovieBinding.searchBtn.setOnClickListener {
            val searchTitle = searchMovieBinding.keywordEt.text.toString()
            if (searchTitle.isNotBlank()) {
                // API 키를 올바르게 전달
                val apiKey = getString(R.string.api_key)
                viewModel.getMovies(apiKey, searchTitle)
            }
        }
    }
}

