package com.example.moviereview

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.InvalidationTracker
import com.example.moviereview.data.database.Review
import com.example.moviereview.databinding.ActivityMainBinding
import com.example.moviereview.ui.CalendarAdapter
import com.example.moviereview.ui.CalendarModel
import com.example.moviereview.ui.ReviewAdapter
import com.example.moviereview.ui.ReviewViewModel
import com.example.moviereview.ui.ReviewViewModelFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.io.encoding.ExperimentalEncodingApi

@OptIn(ExperimentalEncodingApi::class)
class MainActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    private val reviewAdapter by lazy {
        ReviewAdapter(emptyList(), reviewViewModel, this)
    }

    private val reviewViewModel by lazy {
        ViewModelProvider(this, ReviewViewModelFactory((application as ReviewApplication).reviewRepository))
            .get(ReviewViewModel::class.java)
    }

    private val calendarAdapter by lazy {
        CalendarAdapter(
            calendarModel.getDaysOfWeek(),
            calendarModel.getDaysOfMonth(),
            calendarModel
        ) { selectedDay ->
            // 선택한 날짜에 맞는 리뷰 가져오기
            loadReviewsForDate(selectedDay)
        }
    }

    private val calendarModel by lazy {
        CalendarModel()
    }

    val REQUEST_CODE_EDIT_REVIEW = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(binding.root)

        binding.calendarRv.adapter = calendarAdapter
        binding.calendarRv.apply {
            layoutManager = GridLayoutManager(this@MainActivity, 7)
            adapter = calendarAdapter
        }
        binding.reviewListRv.layoutManager = LinearLayoutManager(this)
        binding.reviewListRv.adapter = reviewAdapter
        loadReviewsForDate(formatCalendarDate(calendarModel.getToday()))

        // 초기 달력 설정
        updateYearMonthText()

        binding.ymTv.setOnClickListener {
            val today = calendarModel.getToday()
            calendarModel.setCalendar(today)
            updateCalendar()
        }

        binding.nextMonthTv.setOnClickListener {
            calendarModel.moveToNextMonth()
            updateCalendar()
        }

        binding.prevMonthTv.setOnClickListener {
            calendarModel.moveToPreviousMonth()
            updateCalendar()
        }

        binding.addReviewBtn.setOnClickListener {
            val addReviewIntent = Intent(this, AddReviewActivity::class.java)
            startActivity(addReviewIntent)
        }

    }

    private fun updateCalendar() {
        updateYearMonthText()
        calendarAdapter.updateDays(calendarModel.getDaysOfWeek(), calendarModel.getDaysOfMonth())
    }

    private fun updateYearMonthText() {
        binding.ymTv.text = "${calendarModel.getCurrentYear()}.${calendarModel.getCurrentMonth()}"
    }

    private fun loadReviewsForDate(selectedDay: String) {
        val selectedYear = calendarModel.getCurrentYearInt()
        val selectedMonth = calendarModel.getCurrentMonthInt()
        val selectedDate = "${selectedYear}년 ${selectedMonth + 1}월 ${selectedDay}일"

        // 선택된 날짜를 기반으로 리뷰 데이터를 가져옴 (예: ViewModel 또는 로컬 DB)
        reviewViewModel.getReviewsByDate(selectedDate).observe(this, Observer { reviews ->
            // 리뷰가 변경될 때마다 리사이클러 뷰를 업데이트
            reviewAdapter.updateReviews(reviews)
            reviewAdapter.notifyDataSetChanged()
        })

    }

    fun formatCalendarDate(calendar: Calendar): String {
        val date = calendar.time // Calendar 객체에서 Date 객체 추출
        val format = SimpleDateFormat("yyyy년 MM월 dd일", Locale.KOREA) // 원하는 포맷으로 지정
        return format.format(date) // 포맷된 날짜 반환
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_EDIT_REVIEW && resultCode == RESULT_OK) {
            // 리뷰가 수정되었음을 확인
            val updated = data?.getBooleanExtra("updatedReview", false) ?: false
            if (updated) {
                // 수정된 리뷰가 있으면 해당 날짜에 대한 리뷰를 새로 로드
                val selectedDay = formatCalendarDate(calendarModel.getToday()) // 선택된 날짜로 필터링
                loadReviewsForDate(selectedDay)
            }
        }
    }

}