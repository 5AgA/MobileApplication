package com.example.moviereview.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reviews")
data class Review (
    @PrimaryKey(autoGenerate = true)
    val review_id: Int = 0,
    val title: String,
    val date: String,
    val address: String,
    val rating: Float,
    val review: String
    )
