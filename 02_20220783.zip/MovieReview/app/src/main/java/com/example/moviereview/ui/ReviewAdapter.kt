package com.example.moviereview.ui

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat.startActivityForResult
import androidx.recyclerview.widget.RecyclerView
import com.example.moviereview.R
import com.example.moviereview.data.database.Review
import androidx.lifecycle.LifecycleOwner
import com.example.moviereview.EditReviewActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class ReviewAdapter(private var reviews: List<Review> = emptyList(), private val model: ReviewViewModel, private val activity: AppCompatActivity) :
    RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder>() {

    class ReviewViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val movieTitleTextView: TextView = itemView.findViewById(R.id.reviewTitleTv)
        val addressTextView: TextView = itemView.findViewById(R.id.reviewTheaterTv)
    }

    val REQUEST_CODE_EDIT_REVIEW = 200

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReviewViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.review_item, parent, false)
        return ReviewViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ReviewViewHolder, position: Int) {
        val review = reviews[position]
        holder.movieTitleTextView.text = review.title
        holder.addressTextView.text = review.address

        holder.itemView.setOnClickListener {
            // 리뷰 수정 화면으로 이동
            val intent = Intent(holder.itemView.context, EditReviewActivity::class.java).apply {
                 putExtra("review_id", review.review_id)
                 putExtra("title", review.title)
                 putExtra("date", review.date)
                 putExtra("address", review.address)
                 putExtra("rating", review.rating)
                 putExtra("review", review.review)
            }
            activity.startActivityForResult(intent, REQUEST_CODE_EDIT_REVIEW)

        }

        holder.itemView.setOnLongClickListener {
            // 리뷰 삭제
            CoroutineScope(Dispatchers.IO).launch {
                model.deleteReview(review.review_id)
            }
            true
        }
    }

    override fun getItemCount(): Int {
        return reviews.size
    }

    fun updateReviews(newReviews: List<Review>) {
        reviews = newReviews
        notifyDataSetChanged()
    }

}
