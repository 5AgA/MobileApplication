package com.example.moviereview.ui

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatActivity.RESULT_OK
import androidx.recyclerview.widget.RecyclerView
import com.example.moviereview.R
import com.example.moviereview.data.network.MovieList

class SearchMovieAdapter(private var movies: List<MovieList>, private val context: Context): RecyclerView.Adapter<SearchMovieAdapter.MovieHolder>() {
    inner class MovieHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val title = itemView.findViewById<TextView>(R.id.movieTitleTv)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.movie_item, parent, false)
        return MovieHolder(view)
    }

    override fun onBindViewHolder(holder: MovieHolder, position: Int) {
        val openYear = if (!movies[position].openDt.isNullOrBlank() && movies[position].openDt.length >= 4) {
            "(${movies[position].openDt.substring(0, 4)})"
        } else {
            "" // 날짜 정보가 없거나 길이가 짧을 때 대체 문자열
        }

        val title = "${movies[position].movieNm} $openYear"
        holder.title.text = title

        holder.itemView.setOnClickListener {
            // 클릭한 영화 정보를 상세보기 화면으로 전달
            val resultIntent = Intent().apply {
                putExtra("selected_title", title)
            }
            if(context is AppCompatActivity) {
                context.setResult(RESULT_OK, resultIntent)
                context.finish()
            }
        }
    }

    override fun getItemCount(): Int {
        return movies.size
    }

    // 어댑터에 새로운 영화 목록을 전달하는 함수
    fun updateMovies(newMovies: List<MovieList>) {
        movies = newMovies
        notifyDataSetChanged()
    }
}