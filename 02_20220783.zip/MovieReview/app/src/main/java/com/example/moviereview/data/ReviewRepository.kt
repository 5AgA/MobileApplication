package com.example.moviereview.data

import androidx.lifecycle.LiveData
import com.example.moviereview.data.database.Review
import com.example.moviereview.data.database.ReviewDao

class ReviewRepository(private val reviewDao: ReviewDao) {
    val reviews: LiveData<List<Review>> = reviewDao.selectAllReviews()

    suspend fun insertReview(review: Review) {
        reviewDao.insertReview(review)
    }

    fun getReviewsByDate(date: String): List<Review> {
        return reviewDao.getReviewsByDate(date)
    }

    suspend fun getReviewById(review_id: Int): Review {
        return reviewDao.getReviewById(review_id)
    }

    suspend fun deleteReview(review_id: Int) {
        reviewDao.deleteReview(review_id)
    }

    suspend fun updateReview(review_id: Int, title: String, address: String, date: String, rating: Float, review: String) {
        reviewDao.updateReview(review_id, title, address, date, rating, review)
    }
}