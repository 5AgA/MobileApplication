package com.example.moviereview.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "movie_ref")
data class MovieEntity(
    @PrimaryKey
    val movieCd: String,
    val movieNm: String,
    val openDt: String
)