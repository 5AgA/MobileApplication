package com.example.moviereview

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.moviereview.data.database.Review
import com.example.moviereview.databinding.ActivityAddReviewBinding
import com.example.moviereview.ui.DatePickerFragment
import com.example.moviereview.ui.ReviewViewModel
import com.example.moviereview.ui.ReviewViewModelFactory

class EditReviewActivity : AppCompatActivity(), DatePickerFragment.DateSelectedListener {
    val editReviewBinding by lazy {
        ActivityAddReviewBinding.inflate(layoutInflater)
    }

    val viewModel: ReviewViewModel by viewModels {
        ReviewViewModelFactory((application as ReviewApplication).reviewRepository)
    }

    val REQUEST_CODE_SELECT_THEATER = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(editReviewBinding.root)

        val review_id = intent.getIntExtra("review_id", 0)
        val title = intent.getStringExtra("title")
        val date = intent.getStringExtra("date")
        val address = intent.getStringExtra("address")
        val rating = intent.getFloatExtra("rating", 0.0f)
        val review = intent.getStringExtra("review")

        editReviewBinding.searchTitleTv.setText(title)
        editReviewBinding.selectedDateTv.text = date
        editReviewBinding.addressTv.text = address
        editReviewBinding.addRatingBar.rating = rating
        editReviewBinding.reviewEt.setText(review)


        editReviewBinding.selectedDateTv.setOnClickListener {
            val datePickerFragment = DatePickerFragment()
            datePickerFragment.show(supportFragmentManager, "datePicker")
        }

        editReviewBinding.addressTv.setOnClickListener {
            val selectTheaterIntent = Intent(this, SelectTheaterActivity::class.java)
            startActivityForResult(selectTheaterIntent, REQUEST_CODE_SELECT_THEATER)
        }
        editReviewBinding.cancleAddBtn.setOnClickListener {
            finish()
        }

        editReviewBinding.newReviewBtn.setOnClickListener {
            val id = review_id
            val title = editReviewBinding.searchTitleTv.text.toString()
            val date = editReviewBinding.selectedDateTv.text.toString()
            val address = editReviewBinding.addressTv.text.toString()
            val rating = editReviewBinding.addRatingBar.rating
            val review = editReviewBinding.reviewEt.text.toString()
            if (title.isEmpty() || date.isEmpty() || address.isEmpty() || review.isEmpty()) {
                return@setOnClickListener
            }

            viewModel.updateReview(id, title, address, date, rating, review)

            val resultIntent = Intent()
            resultIntent.putExtra("updatedReview", true)
            setResult(RESULT_OK, resultIntent)

            finish()
        }
    }

    override fun onDateSelected(date: String) {
        editReviewBinding.selectedDateTv.text = date
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_SELECT_THEATER) {
            if (resultCode == RESULT_OK) {
                val selectedLocation = data?.getStringExtra("selected_location")
                editReviewBinding.addressTv.text = selectedLocation
            }
        }
    }
}