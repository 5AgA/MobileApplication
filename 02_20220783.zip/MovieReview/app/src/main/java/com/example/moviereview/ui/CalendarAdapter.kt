package com.example.moviereview.ui

import android.graphics.Color
import android.graphics.Typeface
import android.icu.util.Calendar
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.moviereview.R
import kotlin.text.isNotBlank

class CalendarAdapter(private var daysOfWeek: List<String>, private var days: List<String>, private val model: CalendarModel, private val onDateClick: (String) -> Unit) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_DAY_OF_WEEK = 0
        private const val VIEW_TYPE_DAY = 1
    }

    private var selectedPosition = -1
    private var today = Calendar.getInstance()
    private val todayYear = today.get(Calendar.YEAR)
    private val todayMonth = today.get(Calendar.MONTH)
    private val todayDay = today.get(Calendar.DAY_OF_MONTH)

    class DayOfWeekViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dayOfWeekTextView: TextView = itemView.findViewById(R.id.dayTv)
    }

    class DayViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dayTextView: TextView = itemView.findViewById(R.id.dateTv)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_DAY_OF_WEEK -> {
                val itemView = LayoutInflater.from(parent.context)
                    .inflate(R.layout.day_of_week_item, parent, false)
                DayOfWeekViewHolder(itemView)
            }
            else -> {
                val itemView = LayoutInflater.from(parent.context)
                    .inflate(R.layout.calendar_item, parent, false)
                DayViewHolder(itemView)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is DayOfWeekViewHolder -> {
                holder.dayOfWeekTextView.text = daysOfWeek[position]
            }
            is DayViewHolder -> {
                val dayIndex = position - daysOfWeek.size
                if (dayIndex >= 0 && dayIndex < days.size) {
                    val day = days[dayIndex]
                    holder.dayTextView.text = days[dayIndex]

                    // 날짜가 일요일인지, 토요일인지 확인하고, 해당 색상으로 텍스트 색상 변경
                    if (day.isNotBlank()) {
                        val calendar = Calendar.getInstance()
                        val currentYear = model.getCurrentYearInt()
                        val currentMonth = model.getCurrentMonthInt()
                        calendar.set(Calendar.YEAR, currentYear)
                        calendar.set(Calendar.MONTH, currentMonth)
                        calendar.set(Calendar.DAY_OF_MONTH, day.toInt())

                        if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                            holder.dayTextView.setTextColor(Color.RED)
                        } else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
                            holder.dayTextView.setTextColor(Color.BLUE)
                        } else {
                            holder.dayTextView.setTextColor(Color.BLACK)
                        }
                        // 오늘 날짜인 경우 배경색 변경
                        val isToday = model.getCurrentYearInt() == todayYear &&
                                model.getCurrentMonthInt() == todayMonth &&
                                day.toInt() == todayDay

                        // 초기 로드 시 오늘 날짜를 선택
                        if (isToday && selectedPosition == -1) {
                            selectedPosition = dayIndex
                        }

                        // 아이템 상태 설정
                        when {
                            selectedPosition == dayIndex -> {
                                holder.itemView.setBackgroundResource(R.drawable.rounded_corner_background)
                            }
                            else -> {
                                holder.itemView.setBackgroundColor(Color.TRANSPARENT)
                            }
                        }

                        // 클릭 이벤트 처리
                        holder.itemView.setOnClickListener {
                            val previousSelectedPosition = selectedPosition
                            selectedPosition = dayIndex

                            // 클릭된 날짜를 전달
                            if (day.isNotBlank()) {
                                onDateClick(day)
                            }

                            // 이전 선택된 아이템과 현재 선택된 아이템 갱신
                            if (previousSelectedPosition != -1) {
                                notifyItemChanged(previousSelectedPosition + daysOfWeek.size)
                            }
                            notifyItemChanged(selectedPosition + daysOfWeek.size)
                        }
                    } else {
                        holder.dayTextView.text = " "
                    }

                }
            }
        }
    }

    override fun getItemCount(): Int {
        return daysOfWeek.size + days.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (position < daysOfWeek.size) {
            VIEW_TYPE_DAY_OF_WEEK
        } else {
            VIEW_TYPE_DAY
        }
    }

    fun updateDays(daysOfWeek: List<String>, days: List<String>) {
        this.daysOfWeek = daysOfWeek
        this.days = days
        selectedPosition = -1
        notifyDataSetChanged()
    }
}