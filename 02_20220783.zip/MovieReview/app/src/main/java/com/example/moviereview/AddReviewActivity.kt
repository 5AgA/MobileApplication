package com.example.moviereview

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.moviereview.data.database.Review
import com.example.moviereview.databinding.ActivityAddReviewBinding
import com.example.moviereview.ui.DatePickerFragment
import com.example.moviereview.ui.ReviewViewModel
import com.example.moviereview.ui.ReviewViewModelFactory

class AddReviewActivity : AppCompatActivity(), DatePickerFragment.DateSelectedListener {
    val addReviewBinding by lazy {
        ActivityAddReviewBinding.inflate(layoutInflater)
    }

    val viewModel: ReviewViewModel by viewModels {
        ReviewViewModelFactory((application as ReviewApplication).reviewRepository)
    }

    val REQUEST_CODE_SELECT_THEATER = 100
    val REQUEST_CODDE_SEARCH_MOVIE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(addReviewBinding.root)

        addReviewBinding.searchTitleTv.setOnClickListener{
            val searchMovieIntent = Intent(this, SearchMovieActivity::class.java)
            startActivityForResult(searchMovieIntent, REQUEST_CODDE_SEARCH_MOVIE)
        }

        addReviewBinding.selectedDateTv.setOnClickListener {
            val datePickerFragment = DatePickerFragment()
            datePickerFragment.show(supportFragmentManager, "datePicker")
        }

        addReviewBinding.addressTv.setOnClickListener {
            val selectTheaterIntent = Intent(this, SelectTheaterActivity::class.java)
            startActivityForResult(selectTheaterIntent, REQUEST_CODE_SELECT_THEATER)
        }
        addReviewBinding.cancleAddBtn.setOnClickListener {
            finish()
        }

        addReviewBinding.newReviewBtn.setOnClickListener {
            val title = addReviewBinding.searchTitleTv.text.toString()
            val date = addReviewBinding.selectedDateTv.text.toString()
            val address = addReviewBinding.addressTv.text.toString()
            val rating = addReviewBinding.addRatingBar.rating
            val review = addReviewBinding.reviewEt.text.toString()
            if (title.isEmpty() || date.isEmpty() || address.isEmpty() || review.isEmpty()) {
                return@setOnClickListener
            }
            val movieReview = Review(0, title, date, address, rating, review)

            viewModel.insertReview(movieReview)
            finish()
        }
    }

    override fun onDateSelected(date: String) {
        addReviewBinding.selectedDateTv.text = date
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_SELECT_THEATER) {
            if (resultCode == RESULT_OK) {
                val selectedLocation = data?.getStringExtra("selected_location")
                addReviewBinding.addressTv.text = selectedLocation
            }
        } else if (requestCode == REQUEST_CODDE_SEARCH_MOVIE) {
            if (resultCode == RESULT_OK) {
                val selectedTitle = data?.getStringExtra("selected_title")
                addReviewBinding.searchTitleTv.text = selectedTitle
            }
        }
    }
}