package com.example.moviereview.ui

import java.util.Calendar
import java.util.Locale

class CalendarModel {

    private val calendar = Calendar.getInstance()
    private val daysOfWeek = listOf("일", "월", "화", "수", "목", "금", "토")

    fun getDaysOfMonth(): List<String> {
        val days = mutableListOf<String>()
        val firstDayOfMonth = calendar.clone() as Calendar
        firstDayOfMonth.set(Calendar.DAY_OF_MONTH, 1)
        val firstDayOfWeek = firstDayOfMonth.get(Calendar.DAY_OF_WEEK) - 1
        val maxDayOfMonth = firstDayOfMonth.getActualMaximum(Calendar.DAY_OF_MONTH)

        for (i in 0 until firstDayOfWeek) {
            days.add("")
        }
        for (i in 1..maxDayOfMonth) {
            days.add(i.toString())
        }
        return days
    }

    fun getDaysOfWeek(): List<String> {
        return daysOfWeek
    }

    fun moveToNextMonth() {
        calendar.add(Calendar.MONTH, 1)
    }

    fun moveToPreviousMonth() {
        calendar.add(Calendar.MONTH, -1)
    }

    fun getCurrentMonth(): String {
        return calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault())
    }

    fun getCurrentYear(): String {
        return calendar.get(Calendar.YEAR).toString()

    }

    fun getCurrentMonthInt(): Int {
        return calendar.get(Calendar.MONTH)
    }

    fun getCurrentYearInt(): Int {
        return calendar.get(Calendar.YEAR)
    }

    fun getToday(): Calendar {
        return Calendar.getInstance()
    }

    fun setCalendar(calendar: Calendar) {
        this.calendar.time = calendar.time
    }

}