package com.example.moviereview.data.network

import android.content.Context
import com.example.moviereview.R
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MSService(val context: Context) {
    val TAG = "MSService"
    val movieSearch: MovieSearch

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl(context.resources.getString(R.string.url))
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        movieSearch = retrofit.create(MovieSearch::class.java)
    }

    suspend fun getMovieList(key: String, movieNm: String) : List<MovieList>?{
        val root = movieSearch.getMovieList(key, movieNm)
        val movieListResult = root.movieListResult
        return movieListResult?.movieList
    }
}