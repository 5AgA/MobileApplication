package com.example.moviereview.data.network

data class MovieRoot(
    val movieListResult: MovieListResult?,
)

data class MovieListResult(
    val movieList: List<MovieList>?,
)

data class MovieList(
    val movieCd: String,
    val movieNm: String,
    val openDt: String
)