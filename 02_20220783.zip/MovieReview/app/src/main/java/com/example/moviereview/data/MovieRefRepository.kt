package com.example.moviereview.data

import com.example.moviereview.data.database.MovieEntity
import com.example.moviereview.data.database.MovieRefDao
import com.example.moviereview.data.network.MSService
import com.example.moviereview.data.network.MovieList
import kotlinx.coroutines.flow.Flow

class MovieRefRepository(private val refDao: MovieRefDao, private val refService: MSService) {
    val allRefs : Flow<List<MovieEntity>> = refDao.getAllRefs()

    suspend fun getMovies(key: String, movieNm: String) : List<MovieList>? {
        return refService.getMovieList(key, movieNm)
    }
}