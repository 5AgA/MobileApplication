package com.example.moviereview.ui

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviereview.data.MovieRefRepository
import com.example.moviereview.data.network.MovieList
import kotlinx.coroutines.launch

class MSViewModel(private val repository: MovieRefRepository) : ViewModel() {
    private var _movies = MutableLiveData<List<MovieList>?>()
    val movies = _movies

    fun getMovies(key: String, movieNm: String) = viewModelScope.launch {
        var result: List<MovieList>?
        result = repository.getMovies(key, movieNm)

        _movies.value = result
    }
}