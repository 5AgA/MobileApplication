package com.example.moviereview.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.example.moviereview.data.ReviewRepository
import com.example.moviereview.data.database.Review
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReviewViewModel(var repository: ReviewRepository) : ViewModel() {
    // 전체 리뷰를 LiveData로 가져오기
    var reviews: LiveData<List<Review>> = repository.reviews

    // 리뷰 추가
    fun insertReview(review: Review) = viewModelScope.launch {
        repository.insertReview(review)
    }

    // 날짜별 리뷰 가져오기 (수정됨)
    fun getReviewsByDate(date: String): LiveData<List<Review>> {
        return liveData(Dispatchers.IO) {
            val reviews = repository.getReviewsByDate(date)
            emit(reviews)
        }
    }

    // 특정 리뷰 가져오기
    fun getReviewById(review_id: Int) = viewModelScope.launch {
        repository.getReviewById(review_id)
    }

    // 리뷰 삭제
    fun deleteReview(review_id: Int) = viewModelScope.launch {
        repository.deleteReview(review_id)
    }

    // 리뷰 수정
    fun updateReview(review_id: Int, title: String, address: String, date: String, rating: Float, review: String) = viewModelScope.launch {
        repository.updateReview(review_id, title, address, date, rating, review)
    }
}
