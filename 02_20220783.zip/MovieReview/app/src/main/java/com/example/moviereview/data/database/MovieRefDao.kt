package com.example.moviereview.data.database

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MovieRefDao {
    @Query("SELECT * FROM movie_ref")
    fun getAllRefs() : Flow<List<MovieEntity>>
}