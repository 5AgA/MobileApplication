package com.example.moviereview.data.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ReviewDao {
    @Insert
    suspend fun insertReview(review: Review)

    @Query("Select * FROM reviews WHERE date = :date")
    fun getReviewsByDate(date: String): List<Review>

    @Query("SELECT * FROM reviews WHERE review_id = :review_id")
    suspend fun getReviewById(review_id: Int): Review

    @Query("DELETE FROM reviews WHERE review_id = :review_id")
    suspend fun deleteReview(review_id: Int)

    @Query("UPDATE reviews SET title = :title, address = :address, date = :date, rating = :rating, review = :review WHERE review_id = :review_id")
    suspend fun updateReview(review_id: Int, title: String, address: String, date: String, rating: Float, review: String)

    @Query("SELECT * FROM reviews")
    fun selectAllReviews(): LiveData<List<Review>>

}