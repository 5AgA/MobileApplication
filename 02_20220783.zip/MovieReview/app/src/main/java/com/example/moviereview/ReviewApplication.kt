package com.example.moviereview

import android.app.Application
import com.example.moviereview.data.MovieRefRepository
import com.example.moviereview.data.ReviewRepository
import com.example.moviereview.data.database.MovieRefDatabase
import com.example.moviereview.data.database.ReviewDatabase
import com.example.moviereview.data.network.MSService
import com.example.moviereview.ui.ReviewViewModelFactory

class ReviewApplication: Application() {
    val reviewDatabase by lazy {
        ReviewDatabase.getDatabase(this)
    }

    val reviewDao by lazy {
        reviewDatabase.movieReviewDao()
    }

    val reviewRepository by lazy {
        ReviewRepository(reviewDao)
    }

    val refDatabase by lazy {
        MovieRefDatabase.getDatabase(this)
    }

    val refDao by lazy {
        refDatabase.refDao()
    }

    val refService by lazy {
        MSService(this)
    }

    val refRepository by lazy {
        MovieRefRepository(refDao, refService)
    }
}